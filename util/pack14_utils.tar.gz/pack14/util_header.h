// Headers for the utilities
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

void print_data(FILE *fp);
